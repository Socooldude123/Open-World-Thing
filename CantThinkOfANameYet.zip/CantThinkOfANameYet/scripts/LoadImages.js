// map
const grass1Img = new Image();
grass1Img.src = "imgs/map/grass1.png";
const grass2Img = new Image(); 
grass2Img.src = "imgs/map/grass2.png";
const grass3Img = new Image();
grass3Img.src = "imgs/map/grass3.png";
const grass4Img = new Image();
grass4Img.src = "imgs/map/grass4.png";

//tiles
const house1Img = new Image();
house1Img.src = "imgs/buildings/house1.png";
const woodWorkImg = new Image();
woodWorkImg.src = "imgs/buildings/WoodWork.png";
const stoneWorkImg = new Image();
stoneWorkImg.src = "imgs/buildings/StoneWork.png";

//rescources
const stoneImg = new Image();
stoneImg.src = "imgs/natural/stone.png";
const treeImg = new Image();
treeImg.src = "imgs/natural/tree.png";

//UI


//enteties
const person1Img = new Image();
person1Img.src = "imgs/enteties/person1.png";
const person2Img = new Image();
person2Img.src = "imgs/enteties/person2.png";
const person3Img = new Image();
person3Img.src = "imgs/enteties/person3.png";